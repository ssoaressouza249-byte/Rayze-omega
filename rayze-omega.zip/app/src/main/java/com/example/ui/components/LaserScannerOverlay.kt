package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.ScanStage
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LunarSilver
import com.example.ui.theme.LunarWhite
import com.example.ui.theme.NeonCyan

@Composable
fun LaserScannerOverlay(
  currentStage: ScanStage,
  modifier: Modifier = Modifier,
) {
  val infiniteTransition = rememberInfiniteTransition(label = "laser_scanner")

  // Vertical laser sweep top <-> bottom with RepeatMode.Reverse
  val laserProgress by
    infiniteTransition.animateFloat(
      initialValue = 0f,
      targetValue = 1f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 880, easing = LinearEasing),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "laser_sweep_y",
    )

  // Pulsing futuristic visor in center
  val visorPulse by
    infiniteTransition.animateFloat(
      initialValue = 0.96f,
      targetValue = 1.04f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 520, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "visor_pulse",
    )

  val textPulseAlpha by
    infiniteTransition.animateFloat(
      initialValue = 0.65f,
      targetValue = 1f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 480, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "text_pulse",
    )

  val noRippleSource = remember { MutableInteractionSource() }

  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(Color(0xAD020714))
        .clickable(
          interactionSource = noRippleSource,
          indication = null,
          onClick = {},
        )
        .testTag("laser_scanner_overlay"),
    contentAlignment = Alignment.Center,
  ) {
    // Full-Height Laser Beam & Luminous Trail Canvas
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      val y = laserProgress * h
      val trailHeight = 140.dp.toPx()

      // Luminous trail above & below laser line
      drawRect(
        brush =
          Brush.verticalGradient(
            colors =
              listOf(
                Color.Transparent,
                NeonCyan.copy(alpha = 0.14f),
                NeonCyan.copy(alpha = 0.42f),
                NeonCyan.copy(alpha = 0.14f),
                Color.Transparent,
              ),
            startY = y - trailHeight,
            endY = y + trailHeight,
          ),
        topLeft = Offset(0f, y - trailHeight),
        size = Size(w, trailHeight * 2f),
      )

      // Outer cyan beam glow
      drawLine(
        color = NeonCyan.copy(alpha = 0.72f),
        start = Offset(0f, y),
        end = Offset(w, y),
        strokeWidth = 7.dp.toPx(),
      )

      // Razor-sharp bright neon laser core
      drawLine(
        color = Color(0xFFE6FFFF),
        start = Offset(0f, y),
        end = Offset(w, y),
        strokeWidth = 2.4.dp.toPx(),
      )
    }

    // Center Pulsing Futuristic Visor
    Column(
      modifier =
        Modifier.widthIn(min = 250.dp, max = 330.dp)
          .scale(visorPulse)
          .clip(RoundedCornerShape(22.dp))
          .background(Color(0xE0051126))
          .border(
            width = 1.6.dp,
            brush = Brush.linearGradient(listOf(NeonCyan, ElectricBlue, NeonCyan)),
            shape = RoundedCornerShape(22.dp),
          )
          .padding(horizontal = 24.dp, vertical = 22.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = stringResource(R.string.scanning_title),
        color = NeonCyan,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 22.sp,
        letterSpacing = 2.6.sp,
        modifier = Modifier.alpha(textPulseAlpha),
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(10.dp))

      Box(
        modifier =
          Modifier.clip(RoundedCornerShape(50))
            .background(ElectricBlue.copy(alpha = 0.18f))
            .border(1.dp, NeonCyan.copy(alpha = 0.65f), RoundedCornerShape(50))
            .padding(horizontal = 16.dp, vertical = 7.dp)
      ) {
        Text(
          text = currentStage.label,
          color = LunarWhite,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp,
          letterSpacing = 0.8.sp,
          modifier = Modifier.testTag("scanner_stage_label"),
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        ScanStage.entries.forEach { stage ->
          val active = stage == currentStage
          val completed = stage.ordinal < currentStage.ordinal
          Box(
            modifier =
              Modifier.size(if (active) 10.dp else 7.dp)
                .clip(CircleShape)
                .background(
                  when {
                    active -> NeonCyan
                    completed -> ElectricBlue
                    else -> LunarSilver.copy(alpha = 0.25f)
                  }
                )
          )
        }
      }
    }
  }
}
