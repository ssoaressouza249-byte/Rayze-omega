package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SpaceVoid = Color(0xFF03050C)
val SpaceAbyss = Color(0xFF060B18)
val SpaceCardBg = Color(0xCC091428)
val SpaceChipBg = Color(0xB30B1933)
val ElectricBlue = Color(0xFF00B4FF)
val NeonCyan = Color(0xFF00F0FF)
val CyanBolt = Color(0xFF00D8FF)
val DeepCobalt = Color(0xFF0A2E5C)
val SuccessNeon = Color(0xFF00FFA3)
val LunarWhite = Color(0xFFF0F8FF)
val LunarSilver = Color(0xFFA9C5E2)
val MutedBlueGray = Color(0xFF6E89A8)
val WarningAmber = Color(0xFFFFB74D)
