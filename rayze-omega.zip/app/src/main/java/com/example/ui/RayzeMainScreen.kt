package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.system.FreeFireVariant
import com.example.system.ShizukuStatus
import com.example.system.rememberChoreographerFps
import com.example.ui.components.GalaxyBackground
import com.example.ui.components.LaserScannerOverlay
import com.example.ui.theme.CyanBolt
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LunarSilver
import com.example.ui.theme.LunarWhite
import com.example.ui.theme.MutedBlueGray
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SpaceCardBg
import com.example.ui.theme.SpaceChipBg
import com.example.ui.theme.SpaceVoid
import com.example.ui.theme.SuccessNeon
import com.example.ui.theme.WarningAmber

@Composable
fun RayzeMainScreen(viewModel: RayzeViewModel) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val liveFps = rememberChoreographerFps()
  val snackbarHostState = remember { SnackbarHostState() }
  val notInstalledMsg = stringResource(R.string.free_fire_not_installed)

  LaunchedEffect(uiState.feedbackMessage) {
    val msg = uiState.feedbackMessage
    if (msg != null) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearFeedback()
    }
  }

  val infiniteTransition = rememberInfiniteTransition(label = "core_pulse")
  val coreScale by
    infiniteTransition.animateFloat(
      initialValue = 0.96f,
      targetValue = 1.05f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 1900, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "core_orb_scale",
    )

  Box(modifier = Modifier.fillMaxSize().background(SpaceVoid)) {
    GalaxyBackground(moonCenterYDp = 82f)

    Scaffold(
      containerColor = Color.Transparent,
      contentWindowInsets = WindowInsets(0, 0, 0, 0),
      snackbarHost = {
        SnackbarHost(
          hostState = snackbarHostState,
          modifier = Modifier.navigationBarsPadding().padding(bottom = 16.dp),
        )
      },
    ) { innerPadding ->
      Column(
        modifier =
          Modifier.fillMaxSize()
            .padding(innerPadding)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
      ) {
        // Top Lunar Crest Spacer + Header Text
        Column(
          modifier = Modifier.fillMaxWidth().padding(top = 74.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Text(
            text = stringResource(R.string.app_name),
            color = LunarWhite,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 24.sp,
            letterSpacing = 4.sp,
            textAlign = TextAlign.Center,
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = stringResource(R.string.slogan_moon),
            color = NeonCyan,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            letterSpacing = 2.8.sp,
            textAlign = TextAlign.Center,
          )
        }

        // Center Single Energy Core Super-Module
        Column(
          modifier = Modifier.fillMaxWidth().widthIn(max = 520.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(SpaceCardBg)
                .border(
                  width = 1.4.dp,
                  brush =
                    Brush.linearGradient(
                      colors =
                        if (uiState.isOptimized) {
                          listOf(SuccessNeon.copy(alpha = 0.85f), ElectricBlue, NeonCyan)
                        } else {
                          listOf(
                            ElectricBlue.copy(alpha = 0.75f),
                            NeonCyan.copy(alpha = 0.35f),
                            ElectricBlue.copy(alpha = 0.75f),
                          )
                        }
                    ),
                  shape = RoundedCornerShape(28.dp),
                )
                .padding(horizontal = 20.dp, vertical = 22.dp),
            contentAlignment = Alignment.Center,
          ) {
            Column(
              modifier = Modifier.fillMaxWidth(),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              // Pulsing Energy Core Emblem
              Box(
                modifier =
                  Modifier.size(86.dp)
                    .scale(coreScale)
                    .clip(CircleShape)
                    .background(
                      Brush.radialGradient(
                        colors =
                          listOf(
                            if (uiState.isOptimized) SuccessNeon.copy(alpha = 0.35f)
                            else NeonCyan.copy(alpha = 0.32f),
                            ElectricBlue.copy(alpha = 0.10f),
                            Color.Transparent,
                          )
                      )
                    )
                    .border(
                      width = 2.dp,
                      color = if (uiState.isOptimized) SuccessNeon else NeonCyan,
                      shape = CircleShape,
                    ),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Rounded.Bolt,
                  contentDescription = stringResource(R.string.module_title),
                  tint = if (uiState.isOptimized) SuccessNeon else NeonCyan,
                  modifier = Modifier.size(44.dp),
                )
              }

              Spacer(modifier = Modifier.height(14.dp))

              Text(
                text = stringResource(R.string.module_title),
                color = LunarWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 17.sp,
                letterSpacing = 1.1.sp,
                textAlign = TextAlign.Center,
              )

              Spacer(modifier = Modifier.height(4.dp))

              Text(
                text = stringResource(R.string.module_subtitle),
                color = LunarSilver,
                fontFamily = FontFamily.Default,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
              )

              Spacer(modifier = Modifier.height(14.dp))

              // Subtle Shizuku Status Pill (No commands/paths exposed)
              ShizukuStatusPill(
                status = uiState.shizukuStatus,
                onAuthorizeClick = { viewModel.requestShizukuAuthorization() },
              )

              Spacer(modifier = Modifier.height(16.dp))

              // Compact 2x2 Feature Matrix inside Super-Module
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                ModuleFeatureChip(
                  icon = Icons.Rounded.Speed,
                  label = "120Hz & Display",
                  modifier = Modifier.weight(1f),
                )
                ModuleFeatureChip(
                  icon = Icons.Rounded.TouchApp,
                  label = "Toque & Mira FF",
                  modifier = Modifier.weight(1f),
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                ModuleFeatureChip(
                  icon = Icons.Rounded.Memory,
                  label = "RAM & Sistema",
                  modifier = Modifier.weight(1f),
                )
                ModuleFeatureChip(
                  icon = Icons.Rounded.Wifi,
                  label = "Rede & Ping",
                  modifier = Modifier.weight(1f),
                )
              }

              // Neon Activated Badge revealed after 2.5s laser scan
              AnimatedVisibility(
                visible = uiState.isOptimized && !uiState.isScanning,
                enter = fadeIn(tween(320)) + scaleIn(initialScale = 0.9f),
              ) {
                Row(
                  modifier =
                    Modifier.padding(top = 16.dp)
                      .clip(RoundedCornerShape(50))
                      .background(SuccessNeon.copy(alpha = 0.16f))
                      .border(1.2.dp, SuccessNeon, RoundedCornerShape(50))
                      .padding(horizontal = 16.dp, vertical = 8.dp)
                      .testTag("activated_success_badge"),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.Center,
                ) {
                  Icon(
                    imageVector = Icons.Rounded.CheckCircle,
                    contentDescription = stringResource(R.string.badge_activated),
                    tint = SuccessNeon,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = stringResource(R.string.badge_activated),
                    color = SuccessNeon,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 0.6.sp,
                  )
                }
              }

              Spacer(modifier = Modifier.height(18.dp))

              // Master Action Button
              Button(
                onClick = { viewModel.startOptimization() },
                enabled = !uiState.isScanning,
                modifier =
                  Modifier.fillMaxWidth().height(56.dp).testTag("optimize_all_button"),
                shape = RoundedCornerShape(16.dp),
                colors =
                  ButtonDefaults.buttonColors(
                    containerColor = CyanBolt,
                    contentColor = SpaceVoid,
                    disabledContainerColor = CyanBolt.copy(alpha = 0.45f),
                    disabledContentColor = SpaceVoid,
                  ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Bolt,
                  contentDescription = null,
                  modifier = Modifier.size(22.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = stringResource(R.string.btn_optimize_now),
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 14.sp,
                  letterSpacing = 1.sp,
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Live Telemetry Row (RAM Livre, FPS Atual, Temperatura da Bateria)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            TelemetryCard(
              icon = Icons.Rounded.Memory,
              title = "RAM LIVRE",
              value = uiState.telemetry.freeRamText,
              accent = ElectricBlue,
              modifier = Modifier.weight(1f).testTag("telemetry_ram"),
            )
            TelemetryCard(
              icon = Icons.Rounded.Speed,
              title = "FPS ATUAL",
              value = "$liveFps FPS",
              accent = NeonCyan,
              modifier = Modifier.weight(1f).testTag("telemetry_fps"),
            )
            TelemetryCard(
              icon = Icons.Rounded.Thermostat,
              title = "BATERIA",
              value = uiState.telemetry.batteryTempText,
              accent = SuccessNeon,
              modifier = Modifier.weight(1f).testTag("telemetry_temp"),
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          // ABRIR FREE FIRE / FREE FIRE MAX Shortcut Button
          val ffLabel =
            if (uiState.telemetry.detectedFreeFire == FreeFireVariant.FREE_FIRE_MAX) {
              stringResource(R.string.btn_open_free_fire_max)
            } else {
              stringResource(R.string.btn_open_free_fire)
            }

          OutlinedButton(
            onClick = { viewModel.launchFreeFire(notInstalledMsg) },
            modifier =
              Modifier.fillMaxWidth().height(52.dp).testTag("launch_free_fire_button"),
            shape = RoundedCornerShape(16.dp),
            border =
              BorderStroke(
                width = 1.3.dp,
                brush = Brush.horizontalGradient(listOf(ElectricBlue, NeonCyan)),
              ),
            colors =
              ButtonDefaults.outlinedButtonColors(
                containerColor = SpaceChipBg,
                contentColor = LunarWhite,
              ),
          ) {
            Icon(
              imageVector = Icons.Rounded.PlayArrow,
              contentDescription = null,
              tint = NeonCyan,
              modifier = Modifier.size(22.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = ffLabel,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              letterSpacing = 1.1.sp,
            )
          }
        }

        // Official Footer Credits
        Text(
          text = stringResource(R.string.credits_footer),
          color = MutedBlueGray,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Medium,
          fontSize = 12.sp,
          letterSpacing = 0.8.sp,
          textAlign = TextAlign.Center,
          modifier = Modifier.padding(top = 14.dp, bottom = 4.dp).testTag("credits_footer"),
        )
      }
    }

    // Full-Screen Vertical Laser Scanner Overlay during ~2.5s optimization
    if (uiState.isScanning) {
      LaserScannerOverlay(currentStage = uiState.currentScanStage)
    }
  }
}

@Composable
private fun ShizukuStatusPill(
  status: ShizukuStatus,
  onAuthorizeClick: () -> Unit,
) {
  val (label, accentColor, clickable) =
    when (status) {
      ShizukuStatus.READY -> Triple("Shizuku: Conectado", SuccessNeon, false)
      ShizukuStatus.PERMISSION_REQUIRED ->
        Triple("Shizuku: Toque para Autorizar", WarningAmber, true)
      ShizukuStatus.NOT_RUNNING -> Triple("Modo Sistema Ativo", ElectricBlue, false)
      ShizukuStatus.NOT_INSTALLED -> Triple("Modo Sistema Ativo", ElectricBlue, false)
    }

  Row(
    modifier =
      Modifier.clip(RoundedCornerShape(50))
        .background(accentColor.copy(alpha = 0.12f))
        .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(50))
        .then(if (clickable) Modifier.clickable(onClick = onAuthorizeClick) else Modifier)
        .padding(horizontal = 12.dp, vertical = 5.dp)
        .testTag("shizuku_status_pill"),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(
      imageVector = Icons.Rounded.Shield,
      contentDescription = null,
      tint = accentColor,
      modifier = Modifier.size(14.dp),
    )
    Spacer(modifier = Modifier.width(6.dp))
    Text(
      text = label,
      color = accentColor,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.SemiBold,
      fontSize = 11.sp,
      letterSpacing = 0.5.sp,
    )
  }
}

@Composable
private fun ModuleFeatureChip(
  icon: ImageVector,
  label: String,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier =
      modifier
        .clip(RoundedCornerShape(12.dp))
        .background(SpaceChipBg)
        .border(1.dp, ElectricBlue.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
        .padding(horizontal = 10.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = NeonCyan,
      modifier = Modifier.size(16.dp),
    )
    Spacer(modifier = Modifier.width(6.dp))
    Text(
      text = label,
      color = LunarWhite,
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.Medium,
      fontSize = 11.sp,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
private fun TelemetryCard(
  icon: ImageVector,
  title: String,
  value: String,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(16.dp),
    color = SpaceCardBg,
    border = BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = accent,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        color = LunarWhite,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        maxLines = 1,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = title,
        color = MutedBlueGray,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 9.sp,
        letterSpacing = 0.6.sp,
        maxLines = 1,
      )
    }
  }
}
