package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RayzeDarkColorScheme =
  darkColorScheme(
    primary = ElectricBlue,
    onPrimary = SpaceVoid,
    primaryContainer = DeepCobalt,
    onPrimaryContainer = LunarWhite,
    secondary = NeonCyan,
    onSecondary = SpaceVoid,
    tertiary = CyanBolt,
    background = SpaceVoid,
    onBackground = LunarWhite,
    surface = SpaceAbyss,
    onSurface = LunarWhite,
    surfaceVariant = SpaceCardBg,
    onSurfaceVariant = LunarSilver,
    outline = ElectricBlue.copy(alpha = 0.45f),
    error = Color(0xFFFF4D67),
  )

@Composable
fun RayzeOmegaTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = RayzeDarkColorScheme,
    typography = Typography,
    content = content,
  )
}
