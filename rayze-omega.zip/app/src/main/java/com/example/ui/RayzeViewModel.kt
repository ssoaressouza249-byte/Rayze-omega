package com.example.ui

import android.app.Application
import android.content.pm.PackageManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.system.DeviceTelemetry
import com.example.system.ShizukuStatus
import com.example.system.SystemOptimizer
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

enum class ScanStage(val label: String) {
  FPS_120HZ("FPS 120Hz"),
  TOQUE_MIRA_FF("Toque & Mira FF"),
  LOGS_RASTROS("Logs & Rastros"),
  RAM_SISTEMA("RAM & Sistema"),
}

data class RayzeUiState(
  val isScanning: Boolean = false,
  val currentScanStage: ScanStage = ScanStage.FPS_120HZ,
  val isOptimized: Boolean = false,
  val shizukuStatus: ShizukuStatus = ShizukuStatus.NOT_INSTALLED,
  val telemetry: DeviceTelemetry = DeviceTelemetry(),
  val feedbackMessage: String? = null,
)

class RayzeViewModel(application: Application) : AndroidViewModel(application) {

  private val _uiState = MutableStateFlow(RayzeUiState())
  val uiState: StateFlow<RayzeUiState> = _uiState.asStateFlow()

  private val binderReceivedListener =
    Shizuku.OnBinderReceivedListener { refreshStatusAndTelemetry() }

  private val binderDeadListener =
    Shizuku.OnBinderDeadListener { refreshStatusAndTelemetry() }

  private val permissionResultListener =
    Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
      if (requestCode == SystemOptimizer.SHIZUKU_PERMISSION_CODE) {
        val granted = grantResult == PackageManager.PERMISSION_GRANTED
        _uiState.update {
          it.copy(
            shizukuStatus =
              if (granted) ShizukuStatus.READY else ShizukuStatus.PERMISSION_REQUIRED
          )
        }
      }
    }

  init {
    registerShizukuListeners()
    refreshStatusAndTelemetry()
    startTelemetryTicker()
  }

  private fun registerShizukuListeners() {
    runCatching {
      Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
      Shizuku.addBinderDeadListener(binderDeadListener)
      Shizuku.addRequestPermissionResultListener(permissionResultListener)
    }
  }

  fun refreshStatusAndTelemetry() {
    val context = getApplication<Application>()
    val status = SystemOptimizer.queryShizukuStatus(context)
    val telemetry = SystemOptimizer.readTelemetry(context)
    _uiState.update { it.copy(shizukuStatus = status, telemetry = telemetry) }
  }

  private fun startTelemetryTicker() {
    viewModelScope.launch {
      while (true) {
        delay(2500L)
        if (!_uiState.value.isScanning) {
          refreshStatusAndTelemetry()
        }
      }
    }
  }

  fun requestShizukuAuthorization() {
    SystemOptimizer.requestShizukuPermission()
  }

  fun startOptimization() {
    if (_uiState.value.isScanning) return
    val context = getApplication<Application>()

    viewModelScope.launch {
      _uiState.update {
        it.copy(
          isScanning = true,
          currentScanStage = ScanStage.FPS_120HZ,
          feedbackMessage = null,
        )
      }

      val optimizationJob = async { SystemOptimizer.executeFullOptimization(context) }

      val stages = ScanStage.entries
      for (stage in stages) {
        _uiState.update { it.copy(currentScanStage = stage) }
        delay(640L)
      }

      optimizationJob.await()
      val updatedTelemetry = SystemOptimizer.readTelemetry(context)
      val updatedShizuku = SystemOptimizer.queryShizukuStatus(context)

      _uiState.update {
        it.copy(
          isScanning = false,
          isOptimized = true,
          telemetry = updatedTelemetry,
          shizukuStatus = updatedShizuku,
        )
      }
    }
  }

  fun launchFreeFire(notInstalledMessage: String) {
    val context = getApplication<Application>()
    val launched = SystemOptimizer.launchFreeFire(context)
    if (!launched) {
      _uiState.update { it.copy(feedbackMessage = notInstalledMessage) }
    }
  }

  fun clearFeedback() {
    _uiState.update { it.copy(feedbackMessage = null) }
  }

  override fun onCleared() {
    super.onCleared()
    runCatching {
      Shizuku.removeBinderReceivedListener(binderReceivedListener)
      Shizuku.removeBinderDeadListener(binderDeadListener)
      Shizuku.removeRequestPermissionResultListener(permissionResultListener)
    }
  }
}
