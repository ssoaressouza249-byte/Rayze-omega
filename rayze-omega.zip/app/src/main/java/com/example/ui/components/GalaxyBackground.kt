package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SpaceVoid
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

private data class GalaxyStar(
  val xFraction: Float,
  val yFraction: Float,
  val radiusPx: Float,
  val baseAlpha: Float,
  val phase: Float,
  val speedMultiplier: Float,
  val isCyanTinted: Boolean,
)

@Composable
fun GalaxyBackground(
  moonCenterYDp: Float,
  modifier: Modifier = Modifier,
) {
  val stars = remember {
    val rng = Random(202607)
    List(92) {
      GalaxyStar(
        xFraction = rng.nextFloat(),
        yFraction = rng.nextFloat(),
        radiusPx = 1.1f + rng.nextFloat() * 2.5f,
        baseAlpha = 0.35f + rng.nextFloat() * 0.65f,
        phase = rng.nextFloat() * (2f * PI.toFloat()),
        speedMultiplier = 0.7f + rng.nextFloat() * 1.4f,
        isCyanTinted = rng.nextFloat() > 0.68f,
      )
    }
  }

  val infiniteTransition = rememberInfiniteTransition(label = "galaxy_motion")
  val twinklePhase by
    infiniteTransition.animateFloat(
      initialValue = 0f,
      targetValue = (2f * PI).toFloat(),
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 5200, easing = LinearEasing),
          repeatMode = RepeatMode.Restart,
        ),
      label = "star_twinkle",
    )

  val nebulaBreath by
    infiniteTransition.animateFloat(
      initialValue = 0.85f,
      targetValue = 1.15f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 4600, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "nebula_breath",
    )

  Canvas(modifier = modifier.fillMaxSize()) {
    // 1. Deep Space Base (#03050C)
    drawRect(color = SpaceVoid)

    val w = size.width
    val h = size.height

    // 2. Electric Blue Nebula Clouds (#00B4FF)
    drawCircle(
      brush =
        Brush.radialGradient(
          colors =
            listOf(
              ElectricBlue.copy(alpha = 0.22f * nebulaBreath),
              ElectricBlue.copy(alpha = 0.08f),
              Color.Transparent,
            ),
          center = Offset(w * 0.22f, h * 0.32f),
          radius = w * 0.72f * nebulaBreath,
        ),
      center = Offset(w * 0.22f, h * 0.32f),
      radius = w * 0.72f * nebulaBreath,
    )

    drawCircle(
      brush =
        Brush.radialGradient(
          colors =
            listOf(
              ElectricBlue.copy(alpha = 0.20f),
              NeonCyan.copy(alpha = 0.07f),
              Color.Transparent,
            ),
          center = Offset(w * 0.82f, h * 0.66f),
          radius = w * 0.68f,
        ),
      center = Offset(w * 0.82f, h * 0.66f),
      radius = w * 0.68f,
    )

    drawCircle(
      brush =
        Brush.radialGradient(
          colors =
            listOf(
              ElectricBlue.copy(alpha = 0.16f * nebulaBreath),
              Color.Transparent,
            ),
          center = Offset(w * 0.50f, h * 0.50f),
          radius = w * 0.55f,
        ),
      center = Offset(w * 0.50f, h * 0.50f),
      radius = w * 0.55f,
    )

    // 3. Twinkling Stars
    for (star in stars) {
      val wave = 0.5f + 0.5f * sin(twinklePhase * star.speedMultiplier + star.phase)
      val alpha = (star.baseAlpha * (0.35f + 0.65f * wave)).coerceIn(0.1f, 1f)
      val center = Offset(star.xFraction * w, star.yFraction * h)
      val starColor =
        if (star.isCyanTinted) Color(0xFFB3F4FF).copy(alpha = alpha)
        else Color.White.copy(alpha = alpha)

      if (star.radiusPx > 2.6f) {
        drawCircle(
          color = ElectricBlue.copy(alpha = alpha * 0.28f),
          radius = star.radiusPx * 2.8f,
          center = center,
        )
      }
      drawCircle(color = starColor, radius = star.radiusPx, center = center)
    }

    // 4. Luminous Moon at the Top
    val moonY = (moonCenterYDp * density).coerceIn(h * 0.06f, h * 0.25f)
    val moonCenter = Offset(w * 0.5f, moonY)
    val moonRadius = (w * 0.115f).coerceIn(34.dp.toPx(), 54.dp.toPx())

    // Outer Moon Halo
    drawCircle(
      brush =
        Brush.radialGradient(
          colors =
            listOf(
              NeonCyan.copy(alpha = 0.34f * nebulaBreath),
              ElectricBlue.copy(alpha = 0.14f),
              Color.Transparent,
            ),
          center = moonCenter,
          radius = moonRadius * 2.9f,
        ),
      center = moonCenter,
      radius = moonRadius * 2.9f,
    )

    // Lunar Body
    drawCircle(
      brush =
        Brush.radialGradient(
          colors = listOf(Color(0xFFFFFFFF), Color(0xFFD6F2FF), Color(0xFF74C7F7)),
          center = Offset(moonCenter.x - moonRadius * 0.28f, moonCenter.y - moonRadius * 0.28f),
          radius = moonRadius * 1.35f,
        ),
      center = moonCenter,
      radius = moonRadius,
    )

    // Subtle Lunar Craters
    drawCircle(
      color = Color(0x2A387BB0),
      radius = moonRadius * 0.22f,
      center = Offset(moonCenter.x - moonRadius * 0.28f, moonCenter.y - moonRadius * 0.14f),
    )
    drawCircle(
      color = Color(0x22387BB0),
      radius = moonRadius * 0.15f,
      center = Offset(moonCenter.x + moonRadius * 0.30f, moonCenter.y + moonRadius * 0.18f),
    )
    drawCircle(
      color = Color(0x1C387BB0),
      radius = moonRadius * 0.11f,
      center = Offset(moonCenter.x + moonRadius * 0.08f, moonCenter.y - moonRadius * 0.38f),
    )
  }
}
