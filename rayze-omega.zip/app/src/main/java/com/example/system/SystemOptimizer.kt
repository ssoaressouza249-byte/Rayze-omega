package com.example.system

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.Choreographer
import android.view.Display
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.IRayzeOptimizerService
import com.example.shizuku.RayzeUserService
import java.util.Locale
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

enum class ShizukuStatus {
  READY,
  PERMISSION_REQUIRED,
  NOT_RUNNING,
  NOT_INSTALLED,
}

enum class FreeFireVariant(val packageName: String) {
  FREE_FIRE("com.dts.freefireth"),
  FREE_FIRE_MAX("com.dts.freefiremax"),
}

data class DeviceTelemetry(
  val freeRamText: String = "-- GB",
  val freeRamPercent: Int = 0,
  val batteryTempText: String = "--°C",
  val detectedFreeFire: FreeFireVariant? = null,
)

data class OptimizationOutcome(
  val shizukuExecuted: Boolean,
  val systemExecuted: Boolean,
)

object SystemOptimizer {
  const val SHIZUKU_PERMISSION_CODE = 4096
  private const val SHIZUKU_MANAGER_PKG = "moe.shizuku.privileged.api"
  private var activeWifiLock: WifiManager.WifiLock? = null

  fun queryShizukuStatus(context: Context): ShizukuStatus {
    return runCatching {
        val binderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!binderAlive) {
          val installed =
            runCatching {
                context.packageManager.getPackageInfo(SHIZUKU_MANAGER_PKG, 0)
                true
              }
              .getOrDefault(false)
          return@runCatching if (installed) ShizukuStatus.NOT_RUNNING
          else ShizukuStatus.NOT_INSTALLED
        }

        val granted =
          runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }
            .getOrDefault(false)

        if (granted) ShizukuStatus.READY else ShizukuStatus.PERMISSION_REQUIRED
      }
      .getOrDefault(ShizukuStatus.NOT_INSTALLED)
  }

  fun requestShizukuPermission() {
    runCatching {
      if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
        Shizuku.requestPermission(SHIZUKU_PERMISSION_CODE)
      }
    }
  }

  fun detectFreeFireVariant(context: Context): FreeFireVariant? {
    return runCatching {
        val pm = context.packageManager
        when {
          pm.getLaunchIntentForPackage(FreeFireVariant.FREE_FIRE.packageName) != null ->
            FreeFireVariant.FREE_FIRE
          pm.getLaunchIntentForPackage(FreeFireVariant.FREE_FIRE_MAX.packageName) != null ->
            FreeFireVariant.FREE_FIRE_MAX
          else -> null
        }
      }
      .getOrNull()
  }

  fun launchFreeFire(context: Context): Boolean {
    return runCatching {
        val variant = detectFreeFireVariant(context) ?: return@runCatching false
        val intent =
          context.packageManager.getLaunchIntentForPackage(variant.packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          } ?: return@runCatching false
        context.startActivity(intent)
        true
      }
      .getOrDefault(false)
  }

  fun readTelemetry(context: Context): DeviceTelemetry {
    val (ramText, ramPct) = readMemoryInfo(context)
    val tempText = readBatteryTemperature(context)
    val ffVariant = detectFreeFireVariant(context)
    return DeviceTelemetry(
      freeRamText = ramText,
      freeRamPercent = ramPct,
      batteryTempText = tempText,
      detectedFreeFire = ffVariant,
    )
  }

  private fun readMemoryInfo(context: Context): Pair<String, Int> {
    return runCatching {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(info)
        if (info.totalMem > 0L) {
          val freeGb = info.availMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
          val pct = ((info.availMem.toDouble() / info.totalMem.toDouble()) * 100.0).toInt().coerceIn(0, 100)
          val formatted = String.format(Locale.US, "%.1f GB", freeGb)
          formatted to pct
        } else {
          "-- GB" to 0
        }
      }
      .getOrDefault("-- GB" to 0)
  }

  private fun readBatteryTemperature(context: Context): String {
    return runCatching {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        if (tenths > 0) {
          val celsius = tenths / 10.0f
          String.format(Locale.US, "%.1f°C", celsius)
        } else {
          "--°C"
        }
      }
      .getOrDefault("--°C")
  }

  fun detectMaxRefreshRate(context: Context): Float {
    return runCatching {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = dm?.getDisplay(Display.DEFAULT_DISPLAY)
        val maxMode = display?.supportedModes?.maxOfOrNull { it.refreshRate } ?: 120f
        maxMode.coerceIn(60f, 144f)
      }
      .getOrDefault(120f)
  }

  suspend fun executeFullOptimization(context: Context): OptimizationOutcome {
    return withContext(Dispatchers.IO) {
      val systemOk = runSystemApisOptimization(context)
      val shizukuOk = runShizukuUserServiceOptimization(context)
      OptimizationOutcome(shizukuExecuted = shizukuOk, systemExecuted = systemOk)
    }
  }

  private fun runSystemApisOptimization(context: Context): Boolean {
    return runCatching {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val protectedPkgs =
          setOf(
            context.packageName,
            FreeFireVariant.FREE_FIRE.packageName,
            FreeFireVariant.FREE_FIRE_MAX.packageName,
            SHIZUKU_MANAGER_PKG,
          )

        @Suppress("DEPRECATION")
        val runningProcesses = runCatching { am?.runningAppProcesses }.getOrNull().orEmpty()
        for (proc in runningProcesses) {
          val pkgList = proc.pkgList ?: continue
          for (pkg in pkgList) {
            if (pkg !in protectedPkgs && !pkg.startsWith("com.android.systemui")) {
              runCatching { am?.killBackgroundProcesses(pkg) }
            }
          }
        }

        // Acquire low-latency Wi-Fi lock safely
        runCatching {
          val wifiManager =
            context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
          if (wifiManager != null) {
            val mode =
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
              } else {
                @Suppress("DEPRECATION") WifiManager.WIFI_MODE_FULL_HIGH_PERF
              }
            if (activeWifiLock == null) {
              activeWifiLock =
                wifiManager.createWifiLock(mode, "RayzeOmega:LowLatency").apply {
                  setReferenceCounted(false)
                }
            }
            if (activeWifiLock?.isHeld == false) {
              activeWifiLock?.acquire()
            }
          }
        }

        runCatching { Runtime.getRuntime().gc() }
        true
      }
      .getOrDefault(false)
  }

  private suspend fun runShizukuUserServiceOptimization(context: Context): Boolean {
    val ready = queryShizukuStatus(context) == ShizukuStatus.READY
    if (!ready) return false

    val maxRate = detectMaxRefreshRate(context).toString()
    val targets =
      "${FreeFireVariant.FREE_FIRE.packageName},${FreeFireVariant.FREE_FIRE_MAX.packageName}"

    val args =
      runCatching {
          Shizuku.UserServiceArgs(
              ComponentName(context.packageName, RayzeUserService::class.java.name)
            )
            .daemon(false)
            .processNameSuffix("rayze_core")
            .version(1)
        }
        .getOrNull() ?: return false

    val completion = CompletableDeferred<Boolean>()
    val connection =
      object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
          val success =
            runCatching {
                val remote = IRayzeOptimizerService.Stub.asInterface(service)
                val executed = remote?.executeOptimizationSuite(maxRate, targets) ?: false
                runCatching { remote?.destroy() }
                executed
              }
              .getOrDefault(false)
          if (!completion.isCompleted) {
            completion.complete(success)
          }
          runCatching { Shizuku.unbindUserService(args, this, true) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
          if (!completion.isCompleted) {
            completion.complete(false)
          }
        }
      }

    val bound =
      runCatching {
          Shizuku.bindUserService(args, connection)
          true
        }
        .getOrDefault(false)

    if (!bound) return false

    val result = withTimeoutOrNull(1800L) { completion.await() } ?: false
    if (!completion.isCompleted) {
      runCatching { Shizuku.unbindUserService(args, connection, true) }
    }
    return result
  }
}

@Composable
fun rememberChoreographerFps(): Int {
  var currentFps by remember { mutableIntStateOf(60) }

  DisposableEffect(Unit) {
    var frameCount = 0
    var windowStartNanos = System.nanoTime()
    var active = true

    val callback =
      object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
          if (!active) return
          frameCount++
          val elapsedNanos = frameTimeNanos - windowStartNanos
          if (elapsedNanos >= 500_000_000L) {
            val fps = ((frameCount * 1_000_000_000.0) / elapsedNanos).toInt().coerceIn(1, 144)
            currentFps = fps
            frameCount = 0
            windowStartNanos = frameTimeNanos
          }
          runCatching { Choreographer.getInstance().postFrameCallback(this) }
        }
      }

    runCatching { Choreographer.getInstance().postFrameCallback(callback) }

    onDispose {
      active = false
      runCatching { Choreographer.getInstance().removeFrameCallback(callback) }
    }
  }

  return currentFps
}
