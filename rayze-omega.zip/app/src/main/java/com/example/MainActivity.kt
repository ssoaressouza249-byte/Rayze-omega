package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.security.SecurityGuard
import com.example.security.SecurityViolationScreen
import com.example.ui.RayzeMainScreen
import com.example.ui.RayzeViewModel
import com.example.ui.theme.RayzeOmegaTheme

class MainActivity : ComponentActivity() {

  private val viewModel: RayzeViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
    )

    val authentic = SecurityGuard.isAppAuthentic(this)

    setContent {
      RayzeOmegaTheme {
        if (authentic) {
          RayzeMainScreen(viewModel = viewModel)
        } else {
          SecurityViolationScreen()
        }
      }
    }
  }
}
