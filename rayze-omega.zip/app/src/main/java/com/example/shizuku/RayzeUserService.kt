package com.example.shizuku

import com.example.IRayzeOptimizerService
import kotlin.system.exitProcess

class RayzeUserService : IRayzeOptimizerService.Stub() {

  override fun destroy() {
    runCatching { exitProcess(0) }
  }

  override fun executeOptimizationSuite(
    maxRefreshRate: String,
    targetPackagesCsv: String,
  ): Boolean {
    val rate = maxRefreshRate.toFloatOrNull()?.takeIf { it in 60f..240f }?.toString() ?: "120.0"

    val commands =
      buildList {
        // FPS & Display
        add("settings put system peak_refresh_rate $rate")
        add("settings put system min_refresh_rate $rate")
        add("settings put system user_refresh_rate $rate")
        add("settings put global window_animation_scale 0.0")
        add("settings put global transition_animation_scale 0.0")
        add("settings put global animator_duration_scale 0.0")

        // Touch & Responsiveness
        add("settings put system pointer_speed 7")
        add("settings put secure long_press_timeout 250")
        add("settings put system haptic_feedback_enabled 0")
        add("cmd power set-fixed-performance-mode-enabled true")

        // Free Fire & Free Fire MAX Priority
        targetPackagesCsv
          .split(",")
          .map { it.trim() }
          .filter { it.isNotEmpty() }
          .forEach { pkg ->
            add("cmd activity set-standby-bucket $pkg active")
            add("cmd deviceidle whitelist +$pkg")
            add("pidof $pkg | xargs -r renice -n -10 -p")
          }

        // Logs, Cache & Background RAM Cleanup
        add("pm trim-caches 999999999999")
        add("logcat -c")
        add("am kill-all")
        add("sync")

        // Low-Latency Network
        add("settings put global wifi_sleep_policy 2")
        add("settings put global wifi_scan_always_enabled 0")
        add("settings put global ble_scan_always_enabled 0")
        add("cmd netpolicy set restrict-background false")
      }

    var anySucceeded = false
    for (cmd in commands) {
      val result =
        runCatching {
          val process = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
          process.waitFor() == 0
        }
      if (result.getOrDefault(false)) {
        anySucceeded = true
      }
    }
    return anySucceeded
  }
}
