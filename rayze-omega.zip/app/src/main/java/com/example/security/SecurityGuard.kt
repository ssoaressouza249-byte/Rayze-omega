package com.example.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.GppBad
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

object SecurityGuard {
  private const val EXPECTED_PACKAGE = "com.raylan.rayzeomega"
  private const val EXPECTED_APP_NAME = "RAYZE OMEGA"

  fun isAppAuthentic(context: Context): Boolean {
    return runCatching {
        val currentPackage = context.packageName
        val resourceName = context.getString(R.string.app_name)
        val labelName = context.applicationInfo.loadLabel(context.packageManager).toString()

        currentPackage == EXPECTED_PACKAGE &&
          resourceName == EXPECTED_APP_NAME &&
          labelName == EXPECTED_APP_NAME
      }
      .getOrDefault(false)
  }

  fun launchUninstall(context: Context) {
    runCatching {
      val intent =
        Intent(Intent.ACTION_DELETE).apply {
          data = Uri.parse("package:${context.packageName}")
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      context.startActivity(intent)
    }
  }
}

@Composable
fun SecurityViolationScreen() {
  val context = LocalContext.current

  BackHandler(enabled = true) {}

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(Color(0xFF4A0008), Color(0xFF8F0012), Color(0xFF2B0005))
          )
        )
        .safeDrawingPadding()
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .widthIn(max = 460.dp)
          .clip(RoundedCornerShape(24.dp))
          .background(Color(0xCC1E0004))
          .border(1.5.dp, Color(0xFFFF4D67), RoundedCornerShape(24.dp))
          .padding(28.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Box(
        modifier =
          Modifier.size(84.dp)
            .clip(CircleShape)
            .background(Color(0x33FF1744))
            .border(2.dp, Color(0xFFFF4D67), CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Rounded.GppBad,
          contentDescription = stringResource(R.string.security_alert_title),
          tint = Color(0xFFFF6B7F),
          modifier = Modifier.size(46.dp),
        )
      }

      Spacer(modifier = Modifier.height(22.dp))

      Text(
        text = stringResource(R.string.security_alert_title),
        color = Color.White,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 20.sp,
        letterSpacing = 1.5.sp,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = stringResource(R.string.security_alert_body),
        color = Color(0xFFFFD6DC),
        fontFamily = FontFamily.Default,
        fontSize = 15.sp,
        lineHeight = 22.sp,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(28.dp))

      Button(
        onClick = { SecurityGuard.launchUninstall(context) },
        modifier =
          Modifier.fillMaxWidth().height(54.dp).testTag("security_uninstall_button"),
        shape = RoundedCornerShape(14.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = Color(0xFFFF1744),
            contentColor = Color.White,
          ),
      ) {
        Icon(
          imageVector = Icons.Rounded.DeleteForever,
          contentDescription = null,
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.size(8.dp))
        Text(
          text = stringResource(R.string.btn_uninstall_now),
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp,
          letterSpacing = 1.sp,
        )
      }
    }
  }
}
