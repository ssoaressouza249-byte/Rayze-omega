package com.example;

interface IRayzeOptimizerService {
    void destroy();
    boolean executeOptimizationSuite(String maxRefreshRate, String targetPackagesCsv);
}
