package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.security.SecurityGuard
import com.example.system.SystemOptimizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name and package integrity are valid`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("RAYZE OMEGA", appName)
    assertEquals("com.raylan.rayzeomega", context.packageName)
    assertTrue(SecurityGuard.isAppAuthentic(context))
  }

  @Test
  fun `telemetry reader returns safe values without throwing`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val telemetry = SystemOptimizer.readTelemetry(context)
    assertTrue(telemetry.freeRamText.isNotEmpty())
    assertTrue(telemetry.batteryTempText.isNotEmpty())
  }
}
